const API_URL = "https://is-shortcuts.vercel.app/api/actions";
const SYNC_ALARM = "is-shortcuts-auto-sync";

async function callApi(action, args = {}) {
  const res = await fetch(API_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ action, args })
  });
  const json = await res.json().catch(() => null);
  if (!res.ok) {
    throw new Error(json?.error || `خطأ في الاتصال (${res.status})`);
  }
  return json.data;
}

function rebuildContextMenus(shortcuts = []) {
  chrome.contextMenus.removeAll(() => {
    if (chrome.runtime.lastError) return;
    if (!shortcuts || shortcuts.length === 0) return;

    chrome.contextMenus.create({
      id: "is-root",
      title: "إدراج رد جاهز (IS Shortcuts)",
      contexts: ["editable"]
    });

    const groups = new Map();
    for (const s of shortcuts) {
      const cat = (s.category || "عام").trim();
      if (!groups.has(cat)) groups.set(cat, []);
      groups.get(cat).push(s);
    }

    let catIdx = 0;
    for (const [catName, items] of groups.entries()) {
      const parentId = `is-cat-${catIdx++}`;
      chrome.contextMenus.create({
        id: parentId,
        parentId: "is-root",
        title: `${catName} (${items.length})`,
        contexts: ["editable"]
      });

      items.slice(0, 40).forEach((s) => {
        const prefix = s.trigger ? `[${s.trigger}] ` : "";
        chrome.contextMenus.create({
          id: `is-reply-${s.id}`,
          parentId,
          title: `${prefix}${s.title}`,
          contexts: ["editable"]
        });
      });
    }
  });
}

async function syncShortcuts() {
  const { token, user } = await chrome.storage.local.get(["token", "user"]);
  if (!token) return { ok: false, error: "غير مسجل الدخول" };

  try {
    let currentUser = user;
    if (!currentUser) {
      const meData = await callApi("me", { token });
      if (meData && meData.user) {
        currentUser = meData.user;
        await chrome.storage.local.set({ user: currentUser });
      }
    }

    const data = await callApi("listShortcuts", { token });
    const rawList = data.shortcuts || [];

    const normalizedAll = rawList.map((s) => {
      const siteTrigger = (s.trigger || "").trim();
      const extNote = (s.extShortcut || "").trim();
      const primaryTrigger = siteTrigger || extNote;
      const allTriggers = [];
      if (siteTrigger) allTriggers.push(siteTrigger);
      if (extNote && extNote.toLowerCase() !== siteTrigger.toLowerCase()) {
        allTriggers.push(extNote);
      }

      return {
        id: s.id,
        title: s.title,
        body: s.body,
        category: s.category || "عام",
        tags: s.tags || "",
        trigger: primaryTrigger,
        siteTrigger,
        extShortcut: extNote,
        triggers: allTriggers,
        source: s.source || "",
        pinned: Boolean(s.pinned),
        favorite: Boolean(s.favorite),
        usageCount: s.usageCount || 0
      };
    });

    const activeTriggers = normalizedAll.filter((s) => s.triggers.length > 0);

    await chrome.storage.local.set({
      allShortcuts: normalizedAll,
      shortcuts: activeTriggers,
      allShortcutsCount: normalizedAll.length,
      lastSync: Date.now()
    });

    rebuildContextMenus(normalizedAll);

    return {
      ok: true,
      count: activeTriggers.length,
      total: normalizedAll.length,
      user: currentUser
    };
  } catch (err) {
    if (err.message && (err.message.includes("الجلسة") || err.message.includes("سجّل دخولك"))) {
      await chrome.storage.local.remove(["token", "user", "shortcuts", "allShortcuts", "allShortcutsCount"]);
      rebuildContextMenus([]);
    }
    return { ok: false, error: err.message };
  }
}

async function recordUsage(id) {
  const { token } = await chrome.storage.local.get(["token"]);
  if (token && id) {
    callApi("recordUse", { token, id }).catch(() => {});
  }
}

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const menuId = String(info.menuItemId || "");
  if (!menuId.startsWith("is-reply-") || !tab?.id) return;

  const id = Number(menuId.replace("is-reply-", ""));
  const { allShortcuts = [] } = await chrome.storage.local.get(["allShortcuts"]);
  const found = allShortcuts.find((s) => s.id === id);
  if (!found) return;

  chrome.tabs.sendMessage(
    tab.id,
    { type: "INSERT_TEXT", shortcut: found },
    { frameId: info.frameId },
    () => void chrome.runtime.lastError
  );
  recordUsage(found.id);
});

chrome.commands.onCommand.addListener(async (command) => {
  if (command !== "quick-search") return;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return;
  chrome.tabs.sendMessage(tab.id, { type: "OPEN_QUICK_SEARCH" }, () => void chrome.runtime.lastError);
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === "LOGIN") {
    (async () => {
      try {
        const res = await callApi("login", {
          identifier: msg.identifier,
          password: msg.password
        });
        if (!res.ok || !res.token) {
          sendResponse({ ok: false, error: res.error || "بيانات الدخول غير صحيحة" });
          return;
        }
        await chrome.storage.local.set({
          token: res.token,
          user: res.user,
          enabled: true
        });
        const syncRes = await syncShortcuts();
        sendResponse({ ok: true, user: res.user, sync: syncRes });
      } catch (err) {
        sendResponse({ ok: false, error: err.message });
      }
    })();
    return true;
  }

  if (msg.type === "SYNC_TOKEN_FROM_SITE") {
    (async () => {
      const siteToken = (msg.token || "").trim();
      const { token: storedToken } = await chrome.storage.local.get(["token"]);
      if (!siteToken) {
        sendResponse({ ok: false });
        return;
      }
      if (siteToken !== storedToken) {
        await chrome.storage.local.set({ token: siteToken, enabled: true });
        await chrome.storage.local.remove(["user"]);
      }
      const syncRes = await syncShortcuts();
      sendResponse(syncRes);
    })();
    return true;
  }

  if (msg.type === "SYNC") {
    syncShortcuts().then(sendResponse);
    return true;
  }

  if (msg.type === "LOGOUT") {
    (async () => {
      const { token } = await chrome.storage.local.get(["token"]);
      if (token) {
        callApi("logout", { token }).catch(() => {});
      }
      await chrome.storage.local.remove(["token", "user", "shortcuts", "allShortcuts", "allShortcutsCount", "lastSync"]);
      rebuildContextMenus([]);
      sendResponse({ ok: true });
    })();
    return true;
  }

  if (msg.type === "RECORD_USE") {
    recordUsage(msg.id);
    return false;
  }

  if (msg.type === "INSERT_IN_ACTIVE_TAB") {
    (async () => {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab?.id || !msg.shortcut) {
        sendResponse({ ok: false });
        return;
      }
      chrome.tabs.sendMessage(tab.id, { type: "INSERT_TEXT", shortcut: msg.shortcut }, (resp) => {
        if (chrome.runtime.lastError) {
          sendResponse({ ok: false });
        } else {
          recordUsage(msg.shortcut.id);
          sendResponse({ ok: Boolean(resp?.ok) });
        }
      });
    })();
    return true;
  }
});

chrome.runtime.onMessageExternal.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === "PING") {
    sendResponse({ ok: true, installed: true, version: "3.0.0" });
    return false;
  }
  if (msg?.type === "SYNC_NOW") {
    syncShortcuts().then(sendResponse);
    return true;
  }
});

function setupAlarm() {
  chrome.alarms.create(SYNC_ALARM, { periodInMinutes: 5 });
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === SYNC_ALARM) {
    syncShortcuts();
  }
});

chrome.runtime.onInstalled.addListener(() => {
  setupAlarm();
  chrome.storage.local.get(["enabled", "allShortcuts"], (res) => {
    if (res.enabled === undefined) {
      chrome.storage.local.set({ enabled: true });
    }
    if (res.allShortcuts) {
      rebuildContextMenus(res.allShortcuts);
    }
  });
  syncShortcuts();
});

chrome.runtime.onStartup.addListener(() => {
  setupAlarm();
  syncShortcuts();
});
