const SITE_TOKEN_KEY = "is-session-token";
let syncTimer = null;

function syncTokenWithExtension() {
  try {
    if (!chrome?.runtime?.id) return;
    const token =
      window.localStorage.getItem(SITE_TOKEN_KEY) ||
      window.sessionStorage.getItem(SITE_TOKEN_KEY) ||
      "";
    if (token) {
      chrome.runtime.sendMessage({ type: "SYNC_TOKEN_FROM_SITE", token }, () => void chrome.runtime.lastError);
    }
  } catch (_) {}
}

function scheduleSync(delay = 700) {
  if (syncTimer) clearTimeout(syncTimer);
  syncTimer = setTimeout(() => {
    syncTokenWithExtension();
  }, delay);
}

// Initial sync on page load
syncTokenWithExtension();

// Sync whenever user returns to the site tab or interacts with forms/buttons on the site
document.addEventListener("visibilitychange", () => {
  if (!document.hidden) syncTokenWithExtension();
});

window.addEventListener("focus", () => {
  syncTokenWithExtension();
});

document.addEventListener(
  "click",
  (e) => {
    if (e.target && e.target.closest("button")) {
      scheduleSync(750);
    }
  },
  true
);

document.addEventListener(
  "keydown",
  (e) => {
    if (e.key === "Enter") {
      scheduleSync(750);
    }
  },
  true
);
