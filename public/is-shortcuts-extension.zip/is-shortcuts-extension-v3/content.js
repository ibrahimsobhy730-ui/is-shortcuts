let activeShortcutItems = [];
let triggerEntries = [];
let allShortcuts = [];
let isEnabled = true;
let isReplacing = false;
let lastEditableEl = null;

// Inline autocomplete popup state
let acHost = null;
let acShadow = null;
let acMatches = [];
let acSelectedIndex = 0;
let acCurrentPrefix = "";
let acCurrentTarget = null;

function isRuntimeValid() {
  return typeof chrome !== "undefined" && Boolean(chrome.runtime && chrome.runtime.id);
}

function safeSendMessage(payload, callback) {
  try {
    if (!isRuntimeValid()) return;
    chrome.runtime.sendMessage(payload, (res) => {
      if (chrome.runtime.lastError) return;
      if (typeof callback === "function") callback(res);
    });
  } catch (_) {}
}

function safeStorageGet(keys, callback) {
  try {
    if (!isRuntimeValid()) return;
    chrome.storage.local.get(keys, (res) => {
      if (chrome.runtime.lastError) return;
      callback(res || {});
    });
  } catch (_) {}
}

function normalizeForMatch(str) {
  return (str || "")
    .toLowerCase()
    .replace(/[أإآ]/g, "ا")
    .replace(/ة/g, "ه")
    .replace(/ى/g, "ي");
}

function rebuildTriggerIndex(items) {
  activeShortcutItems = items || [];
  const entries = [];
  for (const item of activeShortcutItems) {
    const list =
      Array.isArray(item.triggers) && item.triggers.length > 0
        ? item.triggers
        : item.trigger
          ? [item.trigger]
          : [];
    for (const rawTrig of list) {
      const trig = (rawTrig || "").trim();
      if (!trig) continue;
      entries.push({
        trig,
        norm: normalizeForMatch(trig),
        startsWithSymbol: /^[^\p{L}\p{N}_]/u.test(trig),
        shortcut: item,
        hasLongerSibling: false
      });
    }
  }
  entries.sort((a, b) => b.trig.length - a.trig.length);
  for (let i = 0; i < entries.length; i++) {
    for (let j = 0; j < entries.length; j++) {
      if (i !== j && entries[j].norm.length > entries[i].norm.length && entries[j].norm.startsWith(entries[i].norm)) {
        entries[i].hasLongerSibling = true;
        break;
      }
    }
  }
  triggerEntries = entries;
}

safeStorageGet(["shortcuts", "allShortcuts", "enabled"], (res) => {
  rebuildTriggerIndex(res.shortcuts || []);
  allShortcuts = res.allShortcuts || activeShortcutItems;
  isEnabled = res.enabled !== false;
});

try {
  if (isRuntimeValid()) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local") return;
      if (changes.shortcuts) {
        rebuildTriggerIndex(changes.shortcuts.newValue || []);
      }
      if (changes.allShortcuts) {
        allShortcuts = changes.allShortcuts.newValue || [];
      }
      if (changes.enabled) {
        isEnabled = changes.enabled.newValue !== false;
        if (!isEnabled) closeAutocomplete();
      }
    });
  }
} catch (_) {}

function getEditableElement(el) {
  if (!el || el === document.body || el === document.documentElement) return null;
  if (
    el.tagName === "TEXTAREA" ||
    (el.tagName === "INPUT" && /^(text|search|email|url|tel|)$/i.test(el.type))
  ) {
    if (el.readOnly || el.disabled) return null;
    return el;
  }
  if (el.isContentEditable) return el;
  return el.closest?.('[contenteditable="true"]') || null;
}

["focusin", "mousedown", "keyup"].forEach((evt) => {
  document.addEventListener(
    evt,
    (e) => {
      const ed = getEditableElement(e.target);
      if (ed) lastEditableEl = ed;
    },
    true
  );
});

function showMiniToast(label) {
  const existing = document.getElementById("is-ext-toast");
  if (existing) existing.remove();

  const toast = document.createElement("div");
  toast.id = "is-ext-toast";
  toast.dir = "rtl";
  toast.textContent = `⚡ ${label}`;
  Object.assign(toast.style, {
    position: "fixed",
    bottom: "18px",
    left: "18px",
    zIndex: "2147483647",
    background: "rgba(15, 23, 42, 0.95)",
    color: "#38bdf8",
    border: "1px solid rgba(56, 189, 248, 0.4)",
    padding: "7px 13px",
    borderRadius: "10px",
    fontSize: "12.5px",
    fontWeight: "600",
    fontFamily: 'system-ui, -apple-system, "Segoe UI", Tahoma, sans-serif',
    boxShadow: "0 10px 25px rgba(0, 0, 0, 0.35)",
    pointerEvents: "none",
    transition: "opacity 0.2s ease"
  });
  document.documentElement.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = "0";
    setTimeout(() => toast.remove(), 220);
  }, 1300);
}

function isWordBoundaryBefore(charBefore) {
  if (!charBefore) return true;
  return /\s|[.,!?؟،؛:()\[\]{}"'<>\/\\|-]/.test(charBefore);
}

function isDelimiterChar(ch) {
  return /[\s.,!?؟،؛:()\[\]{}"']/.test(ch);
}

function findMatchingTrigger(textBeforeCursor) {
  if (!textBeforeCursor || triggerEntries.length === 0) return null;

  // 1. Direct match at the very end of textBeforeCursor
  for (const entry of triggerEntries) {
    if (textBeforeCursor.length < entry.trig.length) continue;
    const candidate = textBeforeCursor.slice(textBeforeCursor.length - entry.trig.length);
    if (normalizeForMatch(candidate) === entry.norm) {
      const charBefore = textBeforeCursor.slice(
        textBeforeCursor.length - entry.trig.length - 1,
        textBeforeCursor.length - entry.trig.length
      );
      if (entry.startsWithSymbol || isWordBoundaryBefore(charBefore)) {
        // If another trigger starts with this trigger (e.g. /s and /sale),
        // wait for a space/punctuation delimiter before expanding the shorter one.
        if (!entry.hasLongerSibling) {
          return {
            shortcut: entry.shortcut,
            replaceLength: entry.trig.length,
            trailingChar: ""
          };
        }
      }
    }
  }

  // 2. Delimiter-triggered match for prefix-overlapping triggers (e.g. "/s " when "/sale" exists)
  const lastChar = textBeforeCursor.slice(-1);
  if (isDelimiterChar(lastChar) && textBeforeCursor.length >= 2) {
    const withoutDelim = textBeforeCursor.slice(0, -1);
    for (const entry of triggerEntries) {
      if (!entry.hasLongerSibling) continue;
      if (withoutDelim.length < entry.trig.length) continue;
      const candidate = withoutDelim.slice(withoutDelim.length - entry.trig.length);
      if (normalizeForMatch(candidate) === entry.norm) {
        const charBefore = withoutDelim.slice(
          withoutDelim.length - entry.trig.length - 1,
          withoutDelim.length - entry.trig.length
        );
        if (entry.startsWithSymbol || isWordBoundaryBefore(charBefore)) {
          return {
            shortcut: entry.shortcut,
            replaceLength: entry.trig.length + 1,
            trailingChar: lastChar === "\n" ? "" : lastChar
          };
        }
      }
    }
  }

  return null;
}

function setNativeInputValue(el, newVal, cursorPos) {
  const proto =
    el.tagName === "TEXTAREA"
      ? window.HTMLTextAreaElement.prototype
      : window.HTMLInputElement.prototype;
  const nativeSetter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
  if (nativeSetter) {
    nativeSetter.call(el, newVal);
  } else {
    el.value = newVal;
  }
  if (typeof cursorPos === "number") {
    el.setSelectionRange(cursorPos, cursorPos);
  }
  el.dispatchEvent(new Event("input", { bubbles: true }));
  el.dispatchEvent(new Event("change", { bubbles: true }));
}

function replaceInInputOrTextarea(el, replaceLength, replacementText) {
  const start = el.selectionStart;
  const end = el.selectionEnd;
  if (start === null || start !== end || start < replaceLength) return false;

  const val = el.value;
  const newStart = start - replaceLength;
  const newVal = val.slice(0, newStart) + replacementText + val.slice(end);

  isReplacing = true;
  try {
    setNativeInputValue(el, newVal, newStart + replacementText.length);
  } finally {
    isReplacing = false;
  }
  return true;
}

function resolveTextNodeAtCursor(sel) {
  if (!sel || !sel.rangeCount || !sel.isCollapsed) return null;
  const range = sel.getRangeAt(0);
  const container = range.startContainer;
  const offset = range.startOffset;

  if (container.nodeType === Node.TEXT_NODE) {
    return { node: container, offset };
  }
  if (container.nodeType === Node.ELEMENT_NODE && offset > 0) {
    const prev = container.childNodes[offset - 1];
    if (prev && prev.nodeType === Node.TEXT_NODE) {
      return { node: prev, offset: (prev.textContent || "").length };
    }
  }
  return null;
}

function replaceInContentEditable(replaceLength, replacementText) {
  const sel = window.getSelection();
  const resolved = resolveTextNodeAtCursor(sel);
  if (!resolved) return false;

  const { node, offset } = resolved;
  if (offset < replaceLength) return false;

  isReplacing = true;
  try {
    const delRange = document.createRange();
    delRange.setStart(node, offset - replaceLength);
    delRange.setEnd(node, offset);
    sel.removeAllRanges();
    sel.addRange(delRange);

    const inserted = document.execCommand("insertText", false, replacementText);
    if (!inserted) {
      delRange.deleteContents();
      const textNode = document.createTextNode(replacementText);
      delRange.insertNode(textNode);
      delRange.setStartAfter(textNode);
      delRange.collapse(true);
      sel.removeAllRanges();
      sel.addRange(delRange);
    }
  } finally {
    isReplacing = false;
  }
  return true;
}

function insertTextAtCursor(text, targetOverride) {
  const el = getEditableElement(targetOverride) || getEditableElement(document.activeElement) || lastEditableEl;
  if (!el) return false;

  if (el.tagName === "TEXTAREA" || el.tagName === "INPUT") {
    el.focus();
    const start = el.selectionStart ?? el.value.length;
    const end = el.selectionEnd ?? el.value.length;
    const newVal = el.value.slice(0, start) + text + el.value.slice(end);
    isReplacing = true;
    try {
      setNativeInputValue(el, newVal, start + text.length);
    } finally {
      isReplacing = false;
    }
    return true;
  }

  el.focus();
  isReplacing = true;
  try {
    const inserted = document.execCommand("insertText", false, text);
    if (!inserted) {
      const sel = window.getSelection();
      if (sel && sel.rangeCount) {
        const range = sel.getRangeAt(0);
        range.deleteContents();
        const tn = document.createTextNode(text);
        range.insertNode(tn);
        range.setStartAfter(tn);
        range.collapse(true);
        sel.removeAllRanges();
        sel.addRange(range);
      }
    }
  } finally {
    isReplacing = false;
  }
  return true;
}

/* ================= Live Inline Autocomplete Dropdown ================= */

function closeAutocomplete() {
  if (acHost) {
    acHost.remove();
    acHost = null;
    acShadow = null;
  }
  acMatches = [];
  acSelectedIndex = 0;
  acCurrentPrefix = "";
  acCurrentTarget = null;
}

function getCaretCoordinates(target) {
  try {
    if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA")) {
      const rect = target.getBoundingClientRect();
      return { left: rect.left + 12, top: rect.bottom + 6, fallbackTop: rect.top - 6 };
    }
    const sel = window.getSelection();
    if (sel && sel.rangeCount > 0) {
      const range = sel.getRangeAt(0).cloneRange();
      range.collapse(true);
      const rects = range.getClientRects();
      if (rects.length > 0) {
        const r = rects[0];
        return { left: r.left, top: r.bottom + 6, fallbackTop: r.top - 6 };
      }
    }
  } catch (_) {}
  if (target) {
    const rect = target.getBoundingClientRect();
    return { left: rect.left + 12, top: rect.bottom + 6, fallbackTop: rect.top - 6 };
  }
  return { left: 24, top: 80, fallbackTop: 80 };
}

function applyAutocompleteSelection(entry) {
  const target = acCurrentTarget;
  const prefixLen = acCurrentPrefix.length;
  closeAutocomplete();
  if (!target || !entry) return;

  let ok = false;
  if (target.tagName === "INPUT" || target.tagName === "TEXTAREA") {
    ok = replaceInInputOrTextarea(target, prefixLen, entry.shortcut.body);
  } else {
    ok = replaceInContentEditable(prefixLen, entry.shortcut.body);
  }
  if (ok) {
    showMiniToast(`${entry.trig} → ${entry.shortcut.title}`);
    safeSendMessage({ type: "RECORD_USE", id: entry.shortcut.id });
  }
}

function renderAutocomplete(target, prefixToken, matches) {
  acCurrentTarget = target;
  acCurrentPrefix = prefixToken;
  acMatches = matches.slice(0, 8);
  if (acSelectedIndex >= acMatches.length) acSelectedIndex = 0;

  if (!acHost) {
    acHost = document.createElement("div");
    acHost.id = "is-ac-host";
    acShadow = acHost.attachShadow({ mode: "open" });
    document.documentElement.appendChild(acHost);
  }

  const pos = getCaretCoordinates(target);
  const boxWidth = 340;
  const left = Math.max(8, Math.min(window.innerWidth - boxWidth - 12, pos.left));
  const openUpwards = pos.top + 230 > window.innerHeight && pos.fallbackTop > 230;
  const topStyle = openUpwards
    ? `bottom: ${Math.max(8, window.innerHeight - pos.fallbackTop)}px;`
    : `top: ${Math.max(8, pos.top)}px;`;

  acShadow.innerHTML = `
    <style>
      * { box-sizing: border-box; font-family: system-ui, -apple-system, "Segoe UI", Tahoma, sans-serif; }
      .panel {
        position: fixed;
        left: ${left}px;
        ${topStyle}
        width: ${boxWidth}px;
        background: #0f172a;
        color: #f8fafc;
        border: 1px solid #334155;
        border-radius: 11px;
        box-shadow: 0 18px 40px rgba(0, 0, 0, 0.55);
        z-index: 2147483647;
        overflow: hidden;
        direction: rtl;
      }
      .hdr {
        padding: 5px 10px;
        background: #090e1c;
        border-bottom: 1px solid #1e293b;
        font-size: 10.5px;
        color: #94a3b8;
        display: flex;
        justify-content: space-between;
      }
      .hdr b { color: #38bdf8; }
      .item {
        padding: 7px 10px;
        cursor: pointer;
        border-bottom: 1px solid rgba(30, 41, 59, 0.5);
        display: flex;
        flex-direction: column;
        gap: 2px;
      }
      .item:last-child { border-bottom: none; }
      .item.active, .item:hover { background: #1e293b; }
      .top-line {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 6px;
      }
      .title {
        font-size: 12px;
        font-weight: 700;
        color: #f1f5f9;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      .trig {
        font-family: monospace;
        font-size: 11px;
        font-weight: 700;
        color: #93c5fd;
        background: #1e3a8a;
        padding: 1px 6px;
        border-radius: 5px;
        direction: ltr;
        flex-shrink: 0;
      }
      .prev {
        font-size: 11px;
        color: #94a3b8;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
    </style>
    <div class="panel" id="panel">
      <div class="hdr">
        <span>⚡ <b>IS Shortcuts</b></span>
        <span>Enter أو Tab للإدراج</span>
      </div>
      <div id="items"></div>
    </div>
  `;

  const list = acShadow.getElementById("items");
  acMatches.forEach((m, idx) => {
    const row = document.createElement("div");
    row.className = "item" + (idx === acSelectedIndex ? " active" : "");
    row.innerHTML = `
      <div class="top-line">
        <span class="title">${m.shortcut.title}</span>
        <span class="trig">${m.trig}</span>
      </div>
      <div class="prev">${m.shortcut.body.replace(/\n+/g, " ")}</div>
    `;
    row.addEventListener("mousedown", (e) => {
      e.preventDefault();
      e.stopPropagation();
      applyAutocompleteSelection(m);
    });
    list.appendChild(row);
  });
}

function updateAutocomplete(target, textBeforeCursor) {
  if (!isEnabled || triggerEntries.length === 0 || !textBeforeCursor) {
    closeAutocomplete();
    return;
  }

  // Extract the current word/token right before the cursor (no whitespace inside)
  const tokenMatch = textBeforeCursor.match(/(?:^|[\s.,!?؟،؛:()\[\]{}"'])([^\s]+)$/);
  if (!tokenMatch) {
    closeAutocomplete();
    return;
  }

  const token = tokenMatch[1];
  const startsWithSlashOrSemi = token.startsWith("/") || token.startsWith(";") || token.startsWith("#");
  if (!startsWithSlashOrSemi && token.length < 2) {
    closeAutocomplete();
    return;
  }

  const normToken = normalizeForMatch(token);
  const matches = triggerEntries.filter((e) => e.norm.startsWith(normToken));

  if (matches.length === 0) {
    closeAutocomplete();
    return;
  }

  renderAutocomplete(target, token, matches);
}

document.addEventListener(
  "keydown",
  (e) => {
    if (!acHost || acMatches.length === 0) return;
    if (e.key === "ArrowDown") {
      e.preventDefault();
      e.stopPropagation();
      acSelectedIndex = (acSelectedIndex + 1) % acMatches.length;
      renderAutocomplete(acCurrentTarget, acCurrentPrefix, acMatches);
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      e.stopPropagation();
      acSelectedIndex = (acSelectedIndex - 1 + acMatches.length) % acMatches.length;
      renderAutocomplete(acCurrentTarget, acCurrentPrefix, acMatches);
    } else if (e.key === "Enter" || e.key === "Tab") {
      e.preventDefault();
      e.stopPropagation();
      applyAutocompleteSelection(acMatches[acSelectedIndex]);
    } else if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation();
      closeAutocomplete();
    }
  },
  true
);

document.addEventListener(
  "blur",
  () => {
    setTimeout(() => {
      if (acHost) closeAutocomplete();
    }, 150);
  },
  true
);

/* ================= Main Input Listener ================= */

function handleInput(e) {
  if (!isEnabled || isReplacing || triggerEntries.length === 0) return;

  const target = getEditableElement(e.target);
  if (!target) return;

  let before = "";
  const isInput = target.tagName === "TEXTAREA" || target.tagName === "INPUT";

  if (isInput) {
    const pos = target.selectionStart;
    if (pos === null || pos !== target.selectionEnd) {
      closeAutocomplete();
      return;
    }
    before = target.value.slice(0, pos);
  } else {
    const sel = window.getSelection();
    const resolved = resolveTextNodeAtCursor(sel);
    if (!resolved) {
      closeAutocomplete();
      return;
    }
    before = (resolved.node.textContent || "").slice(0, resolved.offset);
  }

  // Do not auto-expand on Backspace/Delete, only update autocomplete
  if (e.inputType && e.inputType.startsWith("delete")) {
    updateAutocomplete(target, before);
    return;
  }

  const match = findMatchingTrigger(before);
  if (match) {
    closeAutocomplete();
    const replacement = match.shortcut.body + match.trailingChar;
    const ok = isInput
      ? replaceInInputOrTextarea(target, match.replaceLength, replacement)
      : replaceInContentEditable(match.replaceLength, replacement);

    if (ok) {
      showMiniToast(`${match.shortcut.trigger} → ${match.shortcut.title}`);
      safeSendMessage({ type: "RECORD_USE", id: match.shortcut.id });
      return;
    }
  }

  updateAutocomplete(target, before);
}

document.addEventListener("input", handleInput, true);

/* ================= Quick Search Modal (Ctrl+Shift+Space) ================= */

function openQuickSearchModal() {
  closeAutocomplete();
  const existingHost = document.getElementById("is-quick-search-host");
  if (existingHost) {
    existingHost.remove();
    return;
  }

  const savedTarget = getEditableElement(document.activeElement) || lastEditableEl;
  const host = document.createElement("div");
  host.id = "is-quick-search-host";
  const shadow = host.attachShadow({ mode: "open" });

  let selectedIndex = 0;
  // Prioritize shortcuts that have triggers at the top
  const sortedBase = [...allShortcuts].sort((a, b) => {
    const aHas = a.trigger ? 1 : 0;
    const bHas = b.trigger ? 1 : 0;
    if (aHas !== bHas) return bHas - aHas;
    return (b.usageCount || 0) - (a.usageCount || 0);
  });
  let filtered = [...sortedBase];

  shadow.innerHTML = `
    <style>
      * { box-sizing: border-box; font-family: system-ui, -apple-system, "Segoe UI", Tahoma, sans-serif; }
      .backdrop {
        position: fixed; inset: 0; z-index: 2147483647;
        background: rgba(5, 10, 24, 0.65); backdrop-filter: blur(4px);
        display: flex; align-items: flex-start; justify-content: center; padding-top: 11vh;
      }
      .box {
        width: min(530px, 92vw); background: #0f172a; color: #f8fafc;
        border: 1px solid #1e293b; border-radius: 14px;
        box-shadow: 0 24px 60px rgba(0,0,0,0.55); overflow: hidden; direction: rtl;
      }
      .top {
        padding: 12px 14px; border-bottom: 1px solid #1e293b;
        display: flex; align-items: center; gap: 8px;
      }
      .top input {
        flex: 1; background: transparent; border: none; outline: none;
        color: #f8fafc; font-size: 14px;
      }
      .badge-brand {
        font-size: 11px; font-weight: 700; color: #38bdf8;
        background: rgba(56, 189, 248, 0.12); padding: 3px 8px; border-radius: 6px;
      }
      .results { max-height: 340px; overflow-y: auto; padding: 6px; }
      .row {
        padding: 9px 11px; border-radius: 9px; cursor: pointer;
        display: flex; flex-direction: column; gap: 3px;
      }
      .row.active, .row:hover { background: #1e293b; }
      .row-head { display: flex; justify-content: space-between; align-items: center; gap: 8px; }
      .row-title { font-size: 13px; font-weight: 700; color: #f1f5f9; }
      .row-meta { display: flex; align-items: center; gap: 6px; }
      .cat { font-size: 10.5px; color: #94a3b8; background: #0b1120; padding: 2px 6px; border-radius: 5px; }
      .trig { font-family: monospace; font-size: 11.5px; font-weight: 700; color: #93c5fd; background: #1e3a8a; padding: 2px 7px; border-radius: 5px; direction: ltr; }
      .body-preview {
        font-size: 12px; color: #94a3b8; white-space: nowrap;
        overflow: hidden; text-overflow: ellipsis;
      }
      .empty { padding: 24px; text-align: center; color: #64748b; font-size: 13px; }
      .foot {
        padding: 7px 14px; background: #090e1c; border-top: 1px solid #1e293b;
        font-size: 11px; color: #64748b; display: flex; justify-content: space-between;
      }
    </style>
    <div class="backdrop" id="backdrop">
      <div class="box">
        <div class="top">
          <span class="badge-brand">⚡ IS Shortcuts</span>
          <input id="q" type="text" placeholder="اكتب الاختصار أو العنوان أو نص الرد..." autocomplete="off" />
        </div>
        <div class="results" id="results"></div>
        <div class="foot">
          <span>↑↓ للتنقل · Enter للإدراج · Esc للإغلاق</span>
          <span id="countLabel"></span>
        </div>
      </div>
    </div>
  `;

  document.documentElement.appendChild(host);

  const backdrop = shadow.getElementById("backdrop");
  const input = shadow.getElementById("q");
  const resultsEl = shadow.getElementById("results");
  const countLabel = shadow.getElementById("countLabel");

  function closeModal() {
    host.remove();
    if (savedTarget && typeof savedTarget.focus === "function") {
      savedTarget.focus();
    }
  }

  function pickItem(item) {
    host.remove();
    const ok = insertTextAtCursor(item.body, savedTarget);
    if (ok) {
      showMiniToast(item.trigger ? `${item.trigger} → ${item.title}` : item.title);
      safeSendMessage({ type: "RECORD_USE", id: item.id });
    } else if (navigator.clipboard) {
      navigator.clipboard.writeText(item.body).catch(() => {});
      showMiniToast(`تم النسخ: ${item.title}`);
      safeSendMessage({ type: "RECORD_USE", id: item.id });
    }
  }

  function render() {
    countLabel.textContent = `${filtered.length} رد`;
    resultsEl.innerHTML = "";
    if (filtered.length === 0) {
      resultsEl.innerHTML = `<div class="empty">لا توجد ردود مطابقة</div>`;
      return;
    }
    filtered.slice(0, 50).forEach((s, idx) => {
      const row = document.createElement("div");
      row.className = "row" + (idx === selectedIndex ? " active" : "");
      row.innerHTML = `
        <div class="row-head">
          <span class="row-title">${s.title}</span>
          <div class="row-meta">
            ${s.trigger ? `<span class="trig">⚡ ${s.trigger}</span>` : ""}
            <span class="cat">${s.category || "عام"}</span>
          </div>
        </div>
        <div class="body-preview">${s.body.replace(/\n+/g, " ")}</div>
      `;
      row.addEventListener("click", () => pickItem(s));
      resultsEl.appendChild(row);
    });
  }

  input.addEventListener("input", () => {
    const q = normalizeForMatch(input.value.trim());
    selectedIndex = 0;
    if (!q) {
      filtered = [...sortedBase];
    } else {
      filtered = sortedBase
        .filter(
          (s) =>
            normalizeForMatch(s.trigger || "").includes(q) ||
            normalizeForMatch(s.title).includes(q) ||
            normalizeForMatch(s.body).includes(q) ||
            normalizeForMatch(s.category || "").includes(q) ||
            normalizeForMatch(s.tags || "").includes(q)
        )
        .sort((a, b) => {
          const aExact = normalizeForMatch(a.trigger || "") === q ? 2 : normalizeForMatch(a.trigger || "").startsWith(q) ? 1 : 0;
          const bExact = normalizeForMatch(b.trigger || "") === q ? 2 : normalizeForMatch(b.trigger || "").startsWith(q) ? 1 : 0;
          return bExact - aExact;
        });
    }
    render();
  });

  input.addEventListener("keydown", (e) => {
    const max = Math.min(filtered.length, 50);
    if (e.key === "Escape") {
      e.preventDefault();
      closeModal();
    } else if (e.key === "ArrowDown") {
      e.preventDefault();
      if (max > 0) {
        selectedIndex = (selectedIndex + 1) % max;
        render();
      }
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      if (max > 0) {
        selectedIndex = (selectedIndex - 1 + max) % max;
        render();
      }
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (filtered[selectedIndex]) {
        pickItem(filtered[selectedIndex]);
      }
    }
  });

  backdrop.addEventListener("click", (e) => {
    if (e.target === backdrop) closeModal();
  });

  render();
  setTimeout(() => input.focus(), 10);
}

try {
  if (isRuntimeValid()) {
    chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
      if (msg?.type === "OPEN_QUICK_SEARCH") {
        openQuickSearchModal();
        sendResponse({ ok: true });
        return false;
      }
      if (msg?.type === "INSERT_TEXT" && msg.shortcut) {
        const ok = insertTextAtCursor(msg.shortcut.body);
        if (ok) showMiniToast(msg.shortcut.trigger ? `${msg.shortcut.trigger} → ${msg.shortcut.title}` : msg.shortcut.title);
        sendResponse({ ok });
        return false;
      }
    });
  }
} catch (_) {}
