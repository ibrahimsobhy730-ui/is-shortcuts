@echo off
powershell -NoProfile -ExecutionPolicy Bypass -Command "$parts = (Get-Content -Raw -LiteralPath '%~f0') -split ('###PS_' + 'START###'), 2; if ($parts.Count -eq 2) { & ([scriptblock]::Create($parts[1])) '%~dp0' }"
pause
exit /b
###PS_START###
param([string]$BaseDir)$ErrorActionPreference = "SilentlyContinue"
$BaseDir =$BaseDir.TrimEnd('\', '"')

$src =$null
if (Test-Path (Join-Path $BaseDir "manifest.json")) {
    $src =$BaseDir
} else {
    $found = Get-ChildItem -Path$BaseDir -Filter "manifest.json" -Recurse -Depth 2 | Select-Object -First 1
    if ($found) { $src =$found.DirectoryName }
}

if (-not $src) {
    Write-Host "[Error] manifest.json not found! Put install-extension.bat inside the extracted folder." -ForegroundColor Red
    exit 1
}

$target = Join-Path$env:LOCALAPPDATA "IS-Shortcuts-Extension"
if (-not (Test-Path $target)) { New-Item -ItemType Directory -Path$target -Force | Out-Null }
& robocopy $src$target /MIR /XF "install-extension.bat" "*.zip" | Out-Null
Set-Clipboard -Value $target

$userData = Join-Path$env:LOCALAPPDATA "Google\Chrome\User Data"
$statePath = Join-Path$userData "Local State"
$prof = "Default"
$profEmail = ""

if (Test-Path $statePath) {
    $json = Get-Content -Raw -LiteralPath$statePath -Encoding UTF8 | ConvertFrom-Json
    $cache =$json.profile.info_cache
    if ($cache) {$candidates = @()
        foreach ($prop in$cache.PSObject.Properties) {
            $dirName =$prop.Name
            $dirPath = Join-Path $userData$dirName
            if (-not (Test-Path $dirPath)) { continue }

            $info =$prop.Value
            $activeTime = 0.0
            if ($info.active_time) { $activeTime = [double]$info.active_time }

            $latestTicks = [int64]0$filesToCheck = @()
            $prefFile = Join-Path$dirPath "Preferences"
            if (Test-Path $prefFile) { $filesToCheck += (Get-Item -LiteralPath$prefFile) }
            $sessDir = Join-Path$dirPath "Sessions"
            if (Test-Path $sessDir) {
                $filesToCheck += (Get-ChildItem -LiteralPath$sessDir -File)
            }
            foreach ($f in$filesToCheck) {
                if ($f.LastWriteTimeUtc.Ticks -gt$latestTicks) {
                    $latestTicks =$f.LastWriteTimeUtc.Ticks
                }
            }

            $candidates += [PSCustomObject]@{
                Dir         = $dirName
                Email       = $info.user_name
                LatestTicks = $latestTicks
                ActiveTime  = $activeTime
            }
        }

        if ($candidates.Count -gt 0) {
            $best =$candidates | Sort-Object -Property LatestTicks, ActiveTime -Descending | Select-Object -First 1
            $prof =$best.Dir
            $profEmail =$best.Email
        }
    } elseif ($json.profile.last_used) {
        $prof =$json.profile.last_used
    }
}

$chromeExe = @(
    "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
    "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
    "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
) | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $chromeExe) {$chromeExe = "chrome.exe" }

$argList = "`"--profile-directory=$prof`" --no-first-run --force-renderer-accessibility `"chrome://extensions`""
Start-Process -FilePath $chromeExe -ArgumentList$argList

Add-Type @"
using System;
using System.Runtime.InteropServices;

public class Win32Auto {
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll", SetLastError = true, CharSet = CharSet.Auto)]
    public static extern IntPtr FindWindowEx(IntPtr parentHandle, IntPtr childAfter, string className, string windowTitle);
    [DllImport("user32.dll", SetLastError = true)]
    public static extern IntPtr SendMessageTimeout(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam, uint fuFlags, uint uTimeout, out IntPtr lpdwResult);
    [DllImport("user32.dll")] public static extern bool SetCursorPos(int X, int Y);
    [DllImport("user32.dll")] public static extern void mouse_event(uint dwFlags, int dx, int dy, uint dwData, UIntPtr dwExtraInfo);

    public static void WakeAccessibility(IntPtr hwnd) {
        if (hwnd == IntPtr.Zero) return;
        IntPtr child = FindWindowEx(hwnd, IntPtr.Zero, "Chrome_RenderWidgetHostHWND", null);
        if (child != IntPtr.Zero) {
            IntPtr res;
            SendMessageTimeout(child, 0x003D, IntPtr.Zero, (IntPtr)(-4), 0x0002, 1000, out res);
        }
    }

    public static void ClickPoint(int x, int y) {
        SetCursorPos(x, y);
        System.Threading.Thread.Sleep(60);
        mouse_event(0x0002, 0, 0, 0, UIntPtr.Zero);
        System.Threading.Thread.Sleep(40);
        mouse_event(0x0004, 0, 0, 0, UIntPtr.Zero);
    }
}
"@
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes

function Invoke-UiaElement($el) {
    if (-not $el) { return$false }
    $ip =$null
    if ($el.TryGetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern, [ref]$ip)) {$ip.Invoke()
        return $true
    }
    $tp =$null
    if ($el.TryGetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern,