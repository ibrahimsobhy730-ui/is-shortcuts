const loginView = document.getElementById("loginView");
const mainView = document.getElementById("mainView");
const toggleContainer = document.getElementById("toggleContainer");
const enabledToggle = document.getElementById("enabledToggle");
const loginError = document.getElementById("loginError");
const loginBtn = document.getElementById("loginBtn");
const syncBtn = document.getElementById("syncBtn");
const logoutBtn = document.getElementById("logoutBtn");
const userNameEl = document.getElementById("userName");
const countBadge = document.getElementById("countBadge");
const syncInfo = document.getElementById("syncInfo");
const listEl = document.getElementById("shortcutsList");
const searchInput = document.getElementById("searchInput");
const tabActive = document.getElementById("tabActive");
const tabAll = document.getElementById("tabAll");

let activeShortcuts = [];
let allShortcuts = [];
let currentTab = "active";

function renderList() {
  const q = searchInput.value.trim().toLowerCase();
  const base = currentTab === "active" ? activeShortcuts : allShortcuts;
  const filtered = q
    ? base.filter(
        (s) =>
          (s.trigger && s.trigger.toLowerCase().includes(q)) ||
          s.title.toLowerCase().includes(q) ||
          s.body.toLowerCase().includes(q) ||
          (s.category && s.category.toLowerCase().includes(q)) ||
          (s.tags && s.tags.toLowerCase().includes(q))
      )
    : base;

  countBadge.textContent = `⚡ ${activeShortcuts.length} اختصار / ${allShortcuts.length} رد`;
  listEl.innerHTML = "";

  if (filtered.length === 0) {
    if (currentTab === "active" && allShortcuts.length > 0 && !q) {
      syncInfo.innerHTML = `لديك ${allShortcuts.length} رد، لكن لم تُضف لهم اختصاراً بعد من قسم <b>الاختصارات</b> في الموقع.`;
    } else {
      syncInfo.textContent = q ? "لا توجد نتائج مطابقة لبحثك." : "لا توجد ردود مسجلة بعد.";
    }
    return;
  }

  syncInfo.textContent =
    currentTab === "active"
      ? "اكتب أي اختصار من القائمة داخل أي مربع نص وسيُستبدل بالرد تلقائياً:"
      : "جميع ردودك المحفوظة (انقر إدراج أو نسخ):";

  filtered.forEach((s) => {
    const div = document.createElement("div");
    div.className = "item";

    const info = document.createElement("div");
    info.className = "item-info";
    info.innerHTML = `
      <span class="item-title" title="${s.title}">${s.title}</span>
      <span class="item-cat">${s.category || "عام"}</span>
    `;

    const actions = document.createElement("div");
    actions.className = "item-actions";

    if (s.trigger) {
      const trig = document.createElement("span");
      trig.className = "item-trig";
      trig.title = `اكتب: ${s.trigger}`;
      trig.textContent = `⚡ ${s.trigger}`;
      actions.appendChild(trig);
    }

    const insertBtn = document.createElement("button");
    insertBtn.type = "button";
    insertBtn.className = "mini-btn";
    insertBtn.textContent = "إدراج";
    insertBtn.addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: "INSERT_IN_ACTIVE_TAB", shortcut: s }, (res) => {
        if (res?.ok) {
          window.close();
        } else {
          navigator.clipboard.writeText(s.body);
          insertBtn.textContent = "نُسخ";
          setTimeout(() => (insertBtn.textContent = "إدراج"), 1100);
        }
      });
    });

    const copyBtn = document.createElement("button");
    copyBtn.type = "button";
    copyBtn.className = "mini-btn";
    copyBtn.textContent = "نسخ";
    copyBtn.addEventListener("click", async () => {
      await navigator.clipboard.writeText(s.body);
      copyBtn.textContent = "✓";
      chrome.runtime.sendMessage({ type: "RECORD_USE", id: s.id });
      setTimeout(() => (copyBtn.textContent = "نسخ"), 1100);
    });

    actions.appendChild(insertBtn);
    actions.appendChild(copyBtn);

    div.appendChild(info);
    div.appendChild(actions);
    listEl.appendChild(div);
  });
}

function showMain(user, enabled) {
  loginView.style.display = "none";
  mainView.style.display = "block";
  toggleContainer.style.display = "flex";
  userNameEl.textContent = user?.name || "مستخدم";
  enabledToggle.checked = enabled !== false;
  renderList();
}

function showLogin() {
  mainView.style.display = "none";
  toggleContainer.style.display = "none";
  loginView.style.display = "block";
}

chrome.storage.local.get(["token", "user", "shortcuts", "allShortcuts", "enabled"], (res) => {
  activeShortcuts = res.shortcuts || [];
  allShortcuts = res.allShortcuts || activeShortcuts;

  if (res.token) {
    showMain(res.user, res.enabled);
    chrome.runtime.sendMessage({ type: "SYNC" }, (syncRes) => {
      if (syncRes && syncRes.ok) {
        chrome.storage.local.get(["user", "shortcuts", "allShortcuts"], (updated) => {
          activeShortcuts = updated.shortcuts || [];
          allShortcuts = updated.allShortcuts || activeShortcuts;
          if (updated.user?.name) userNameEl.textContent = updated.user.name;
          renderList();
        });
      }
    });
  } else {
    showLogin();
  }
});

tabActive.addEventListener("click", () => {
  currentTab = "active";
  tabActive.classList.add("active");
  tabAll.classList.remove("active");
  renderList();
});

tabAll.addEventListener("click", () => {
  currentTab = "all";
  tabAll.classList.add("active");
  tabActive.classList.remove("active");
  renderList();
});

searchInput.addEventListener("input", renderList);

loginBtn.addEventListener("click", () => {
  const identifier = document.getElementById("identifier").value.trim();
  const password = document.getElementById("password").value;
  loginError.style.display = "none";

  if (!identifier || !password) {
    loginError.textContent = "اكتب البريد/الموبايل وكلمة المرور";
    loginError.style.display = "block";
    return;
  }

  loginBtn.disabled = true;
  loginBtn.textContent = "جاري الدخول...";

  chrome.runtime.sendMessage({ type: "LOGIN", identifier, password }, (res) => {
    loginBtn.disabled = false;
    loginBtn.textContent = "تسجيل الدخول";

    if (!res || !res.ok) {
      loginError.textContent = res?.error || "فشل تسجيل الدخول";
      loginError.style.display = "block";
      return;
    }

    chrome.storage.local.get(["shortcuts", "allShortcuts", "enabled"], (st) => {
      activeShortcuts = st.shortcuts || [];
      allShortcuts = st.allShortcuts || activeShortcuts;
      showMain(res.user, st.enabled);
    });
  });
});

syncBtn.addEventListener("click", () => {
  syncBtn.disabled = true;
  syncBtn.textContent = "جاري التحديث...";
  chrome.runtime.sendMessage({ type: "SYNC" }, (res) => {
    syncBtn.disabled = false;
    syncBtn.textContent = "🔄 تحديث الاختصارات الآن";
    if (res && res.ok) {
      chrome.storage.local.get(["shortcuts", "allShortcuts"], (st) => {
        activeShortcuts = st.shortcuts || [];
        allShortcuts = st.allShortcuts || activeShortcuts;
        renderList();
      });
    } else if (res && res.error) {
      syncInfo.textContent = "خطأ: " + res.error;
    }
  });
});

enabledToggle.addEventListener("change", () => {
  chrome.storage.local.set({ enabled: enabledToggle.checked });
});

logoutBtn.addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "LOGOUT" }, () => {
    activeShortcuts = [];
    allShortcuts = [];
    showLogin();
  });
});
